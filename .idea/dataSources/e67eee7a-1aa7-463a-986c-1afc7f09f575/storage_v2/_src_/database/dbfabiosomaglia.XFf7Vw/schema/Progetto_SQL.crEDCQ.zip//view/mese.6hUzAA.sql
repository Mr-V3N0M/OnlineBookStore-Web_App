CREATE VIEW mese AS SELECT sqmese.t_mese
   FROM ( SELECT release.name,
            release_country.date_day,
            release_country.date_month AS t_mese,
            release_country.date_year,
            area.name
           FROM ((("Progetto SQL".release
             JOIN "Progetto SQL".release_country ON ((release.id = release_country.release)))
             JOIN "Progetto SQL".country_area ON ((release_country.country = country_area.area)))
             JOIN "Progetto SQL".area ON (((country_area.area = area.id) AND ((area.name)::text = 'Italy'::text))))
          WHERE ((release_country.date_year <= ALL ( SELECT anno.date_year
                   FROM "Progetto SQL".anno)) AND (release_country.date_month IS NOT NULL))) sqmese(name, date_day, t_mese, date_year, name_1);
