CREATE VIEW giorno AS SELECT sqgiorno.t_giorno
   FROM ( SELECT release.name,
            release_country.date_day AS t_giorno,
            release_country.date_month,
            release_country.date_year,
            area.name
           FROM ((("Progetto SQL".release
             JOIN "Progetto SQL".release_country ON ((release.id = release_country.release)))
             JOIN "Progetto SQL".country_area ON ((release_country.country = country_area.area)))
             JOIN "Progetto SQL".area ON (((country_area.area = area.id) AND ((area.name)::text = 'Italy'::text))))
          WHERE (((release_country.date_year <= ALL ( SELECT anno.date_year
                   FROM "Progetto SQL".anno)) AND (release_country.date_month <= ALL ( SELECT mese.t_mese
                   FROM "Progetto SQL".mese))) AND (release_country.date_day IS NOT NULL))) sqgiorno(name, t_giorno, date_month, date_year, name_1);
